---
name: Aury Engineering Interface
colors:
  surface: '#101419'
  surface-dim: '#101419'
  surface-bright: '#36393f'
  surface-container-lowest: '#0b0e14'
  surface-container-low: '#181c21'
  surface-container: '#1c2025'
  surface-container-high: '#272a30'
  surface-container-highest: '#32353b'
  on-surface: '#e0e2ea'
  on-surface-variant: '#c0c7d4'
  inverse-surface: '#e0e2ea'
  inverse-on-surface: '#2d3136'
  outline: '#8b919d'
  outline-variant: '#414752'
  surface-tint: '#a2c9ff'
  primary: '#a2c9ff'
  on-primary: '#00315c'
  primary-container: '#58a6ff'
  on-primary-container: '#003a6b'
  inverse-primary: '#0060aa'
  secondary: '#afc6ff'
  on-secondary: '#002d6d'
  secondary-container: '#0064e0'
  on-secondary-container: '#e7ebff'
  tertiary: '#ffba42'
  on-tertiary: '#432c00'
  tertiary-container: '#da9600'
  on-tertiary-container: '#4f3400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d3e4ff'
  primary-fixed-dim: '#a2c9ff'
  on-primary-fixed: '#001c38'
  on-primary-fixed-variant: '#004882'
  secondary-fixed: '#d9e2ff'
  secondary-fixed-dim: '#afc6ff'
  on-secondary-fixed: '#001944'
  on-secondary-fixed-variant: '#004299'
  tertiary-fixed: '#ffddaf'
  tertiary-fixed-dim: '#ffba42'
  on-tertiary-fixed: '#281800'
  on-tertiary-fixed-variant: '#614000'
  background: '#101419'
  on-background: '#e0e2ea'
  surface-variant: '#32353b'
typography:
  h1:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  mono-num:
    fontFamily: monospace
    fontSize: inherit
    fontWeight: inherit
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin: 24px
---

## Brand & Style

This design system is engineered for technical proficiency, targeting power users who require high information density and precise tooling. The aesthetic is rooted in **Minimalism** and **Corporate Modernism**, drawing inspiration from developer-centric platforms like Vercel and Linear. 

The visual language prioritizes utility over decoration. It avoids ephemeral trends such as glowing gradients or heavy blurs, opting instead for a structured, "work-bench" feel. The emotional response is one of reliability, speed, and technical authority. Every element serves a functional purpose, ensuring that the interface remains unobtrusive during complex workflows.

## Colors

The palette is a refined dark-mode spectrum designed for long-duration usage. The foundation is a deep navy-black that reduces eye strain while providing high contrast for text.

- **Primary & Accent:** The primary blue is used for highlights and interactive states, while the deeper accent blue is reserved for solid-action buttons to maintain a professional, tool-like appearance.
- **Surface Strategy:** Layers are defined by subtle shifts in hex value rather than shadows. The base background is the deepest level, with containers and modals stepping up in lightness to signify hierarchy.
- **Semantic Colors:** Success, Warning, and Error colors follow standard industry conventions but are calibrated for maximum legibility against the dark background.

## Typography

The system utilizes **Inter** for its exceptional legibility and systematic feel. Headings are set at a semi-bold (600) weight to provide clear structural anchoring without appearing overly heavy. 

A critical requirement of this design system is the use of **tabular-nums (Monospace)** for all numerical data. This ensures that columns of numbers in tables, dashboards, and metrics remain perfectly aligned, facilitating rapid scanning and comparison. Body text remains at a standard 400 weight to maintain a clean, balanced look in high-density layouts.

## Layout & Spacing

This design system employs a **Fluid Grid** with a high-density spacing philosophy. The rhythm is based on a 4px baseline, allowing for tight, data-rich interfaces that maximize screen real estate for power users.

Layouts should favor structural grouping over whitespace. Sidebars and navigation panels are fixed, while the main content area expands to fill the viewport. Internal padding within components (cards/inputs) should be kept compact (typically 8px to 12px) to support the "tool-centric" nature of the product.

## Elevation & Depth

Hierarchy is established through **Tonal Layering** and **Structural Outlines**. Instead of relying on shadows, which can muddy a dark UI, this system uses 1px borders (#30363d) to define boundaries.

1. **Base Layer:** Background (#0d1117).
2. **Surface Layer:** Cards and secondary containers (#161b22) with a 1px border.
3. **Elevated Layer:** Modals, popovers, and dropdown menus (#21262d).

This "stacked" approach creates a clear sense of depth and focus while maintaining a crisp, flat aesthetic.

## Shapes

The shape language is precise and disciplined. Most components, including cards, input fields, and buttons, utilize a **6px corner radius**. This provides a subtle "softness" that prevents the UI from feeling aggressive while remaining much sharper and more technical than consumer-facing "pill" styles.

The only exception to this rule is **Status Badges**, which use a fully rounded (pill) shape to distinguish them as metadata elements rather than interactive containers.

## Components

- **Buttons:** Use the solid Accent color (#1f6feb) for primary actions. No gradients or shadows; use a flat fill with white text. Secondary buttons should use the Surface-2 background with a 1px border.
- **Input Fields:** 6px radius, background #161b22, and a 1px border. On focus, the border color shifts to Primary (#58a6ff).
- **Cards:** Use Surface (#161b22) with a 1px border. Internal padding should be 16px to maintain density.
- **Status Badges:** Small pill-shaped badges with a 15% opacity background of their respective semantic color (e.g., Success green at 15% opacity) and 100% opacity text.
- **Progress Bars:** 6px in height with fully rounded ends. The track uses the border color (#30363d), and the fill uses the Primary blue.
- **Lists:** High-density rows with 1px bottom borders. Hover states should use a subtle highlight of Surface-2.
- **Monospace Elements:** Code snippets, IDs, and financial/technical data must always render in monospace to ensure character alignment.